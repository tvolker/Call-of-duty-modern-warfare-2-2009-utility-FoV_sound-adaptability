﻿$ErrorActionPreference = "Stop"
if ([IntPtr]::Size -ne 8) { throw "Use 64-bit Windows PowerShell to launch this utility." }
$script:RecentStatus = @()
$script:LogPath = Join-Path $PSScriptRoot "mw2-utility-log.txt"

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$ExpectedHash = "FD3AFF1F539525F5A798C5F5953DDBF651037AFBC52D50C5ABBEA749EFD2ABE2"

# These values are populated only by the validated executable resolver.
$FovPointerRva = $ClIngamePtrRva = $ChannelCountRva = $ChannelTableRva = $StateBaseRva = $ActiveStatePtrRva = [Int64]0
$FovCurrentOffset = [Int64]0x10

$ChannelRecordSize = [Int64]0x50
$StateBlockSize    = [Int64]0x304
$StateEntrySize    = [Int64]0x0C
$BlockCount        = 4

$AllMusicTargets = @(
    @{ Index = 13; Name = "menu" },
    @{ Index = 32; Name = "music" },
    @{ Index = 33; Name = "musicnopause" }
)

$MenuOnlyTargets = @(
    @{ Index = 13; Name = "menu" }
)

Add-Type @"
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;


public static class MW2AddressResolver
{
    static byte[] data;
    static int textRaw, textSize, textRva;
    static int[,] sections;
    static int U16(int o) { return BitConverter.ToUInt16(data,o); }
    static int I32(int o) { return BitConverter.ToInt32(data,o); }
    static int Raw(int rva) {
        for(int i=0;i<sections.GetLength(0);i++) {
            long delta=(long)rva-sections[i,0];
            if(delta>=0 && delta<sections[i,1]) return checked(sections[i,2]+(int)delta);
        }
        throw new Exception("Resolver: address has no file bytes.");
    }
    static int Rva(int raw) { return checked(raw-textRaw+textRva); }
    static int Rip(int raw, int length, int displacement) { return checked(Rva(raw)+length+I32(raw+displacement)); }
    static bool Match(int o, string pattern) {
        string[] items=pattern.Split(' ');
        if(o<0 || (long)o+items.Length>data.Length) return false;
        for(int j=0;j<items.Length;j++) if(items[j]!="??" && data[o+j]!=Convert.ToByte(items[j],16)) return false;
        return true;
    }
    static int Find(string pattern) {
        string[] items=pattern.Split(' '); int[] bytes=new int[items.Length];
        for(int j=0;j<items.Length;j++) bytes[j]=items[j]=="??"?-1:Convert.ToInt32(items[j],16);
        int found=-1;
        for(int i=textRaw;i<=textRaw+textSize-bytes.Length;i++) {
            if(bytes[0]>=0 && data[i]!=bytes[0]) continue;
            bool ok=true;
            for(int j=1;j<bytes.Length;j++) if(bytes[j]>=0 && data[i+j]!=bytes[j]) { ok=false; break; }
            if(ok) { if(found!=-1) throw new Exception("Resolver: ambiguous code signature; no writes."); found=i; }
        }
        if(found<0) throw new Exception("Resolver: code signature changed; manual update required.");
        return found;
    }
    static void Require(bool ok, string why) { if(!ok) throw new Exception("Resolver: "+why); }
    static void Name(int rva, string name) {
        int o=Raw(rva); byte[] bytes=Encoding.ASCII.GetBytes(name+"\0");
        for(int i=0;i<bytes.Length;i++) Require(data[o+i]==bytes[i],"setting name mismatch.");
    }
    static void Writable(int rva, int size) {
        for(int i=0;i<sections.GetLength(0);i++) {
            long delta=(long)rva-sections[i,0];
            if(delta>=0 && delta+size<=sections[i,3] && (sections[i,4]&unchecked((int)0x80000000))!=0) return;
        }
        throw new Exception("Resolver: target outside writable data section.");
    }
    public static long[] Resolve(string path) {
        data=System.IO.File.ReadAllBytes(path);
        Require(data.Length>256,"file too small.");
        int pe=I32(60); Require(pe>=0 && pe<data.Length-256,"invalid PE header.");
        Require(I32(pe)==0x4550 && U16(pe+4)==0x8664 && U16(pe+24)==0x20b,"expected x64 PE.");
        int n=U16(pe+6), table=pe+24+U16(pe+20); Require(n>0 && n<=96,"invalid sections.");
        sections=new int[n,5];textSize=0;
        for(int i=0;i<n;i++) {
            int o=table+40*i;int raw=I32(o+20),size=I32(o+16);
            Require(raw>=0 && size>=0 && (long)raw+size<=data.Length,"invalid section bounds.");
            sections[i,0]=I32(o+12);sections[i,1]=size;sections[i,2]=raw;
            sections[i,3]=Math.Max(size,I32(o+8));sections[i,4]=I32(o+36);
            if(Encoding.ASCII.GetString(data,o,8).TrimEnd('\0')==".text") {
                textRaw=raw;textSize=size;textRva=I32(o+12);
            }
        }
        Require(textSize>0,"missing text section.");
        int f=Find("48 8D 0D ?? ?? ?? ?? F3 0F 10 1D ?? ?? ?? ?? 0F 28 D1 48 89 05 ?? ?? ?? ?? 48 8D 05 ?? ?? ?? ?? 48 89 44 24 28 C7 44 24 20 44 00 00 00 E8");
        Name(Rip(f,7,3),"cg_fov");
        Require(Match(f+91,"48 89 05"),"FOV registration changed.");
        int fov=Rip(f+91,7,3);
        int camera=Find("48 8B 05 ?? ?? ?? ?? 48 8D 0D ?? ?? ?? ?? 8B D3 F3 0F 10 78 10 E8");
        Require(Rip(camera,7,3)==fov,"camera and FOV registration disagree.");
        int g=Find("48 8D 0D ?? ?? ?? ?? 41 B8 00 20 01 00 E8 ?? ?? ?? ?? 48 89 05");
        Name(Rip(g,7,3),"cl_ingame"); int ingame=Rip(g+18,7,3);
        int m=Find("4C 8D 1D ?? ?? ?? ?? 4C 69 C8 04 03 00 00 4D 03 CB 41 C6 81 00 03 00 00 00 4C 3B 0D");
        int state=Rip(m,7,3), active=Rip(m+25,7,3);
        Require(Match(m+113,"44 39 05"),"mixer count reference changed.");
        int count=Rip(m+113,7,3);
        Require(Match(m+185,"48 83 C1 0C"),"mixer entry stride changed.");
        int t=Find("39 1D ?? ?? ?? ?? 7E ?? 48 8D 35 ?? ?? ?? ?? 0F 1F 40 00 66 0F 1F 84 00 00 00 00 00 48 63 C3 48 8B CF 48 8D 14 80 48 C1 E2 04 48 03 D6");
        Require(Rip(t,6,2)==count,"channel counts disagree."); int channels=Rip(t+8,7,3);
        Writable(fov,8);Writable(ingame,8);Writable(state,4*0x304);Writable(active,8);Writable(count,4);Writable(channels,64*0x50);
        return new long[] {fov,ingame,count,channels,state,active};
    }
}

public static class MW2SafeUtilityMemoryV2
{
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern IntPtr OpenProcess(uint access, bool inherit, int pid);

    [DllImport("kernel32.dll", SetLastError=true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    static extern bool ReadProcessMemory(
        IntPtr h, IntPtr address, [Out] byte[] buffer,
        UIntPtr size, out UIntPtr read);

    [DllImport("kernel32.dll", SetLastError=true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    static extern bool WriteProcessMemory(
        IntPtr h, IntPtr address, byte[] buffer,
        UIntPtr size, out UIntPtr written);

    [DllImport("kernel32.dll", SetLastError=true)]
    static extern bool CloseHandle(IntPtr h);

    public static IntPtr Open(int pid)
    {
        const uint VM_OPERATION = 0x0008;
        const uint VM_READ      = 0x0010;
        const uint VM_WRITE     = 0x0020;
        const uint QUERY        = 0x0400;

        IntPtr h = OpenProcess(
            VM_OPERATION | VM_READ | VM_WRITE | QUERY,
            false,
            pid);

        if (h == IntPtr.Zero)
            throw new Win32Exception(
                Marshal.GetLastWin32Error(),
                "OpenProcess failed");

        return h;
    }

    public static byte[] ReadBytes(IntPtr h, long address, int count)
    {
        byte[] buffer = new byte[count];
        UIntPtr got;

        bool ok = ReadProcessMemory(
            h,
            new IntPtr(address),
            buffer,
            new UIntPtr((uint)count),
            out got);

        if (!ok || got.ToUInt64() != (ulong)count)
            throw new Win32Exception(
                Marshal.GetLastWin32Error(),
                "ReadProcessMemory failed at 0x" + address.ToString("X"));

        return buffer;
    }

    public static long ReadInt64(IntPtr h, long address)
    {
        return BitConverter.ToInt64(ReadBytes(h, address, 8), 0);
    }

    public static int ReadInt32(IntPtr h, long address)
    {
        return BitConverter.ToInt32(ReadBytes(h, address, 4), 0);
    }

    public static byte ReadByte(IntPtr h, long address)
    {
        return ReadBytes(h, address, 1)[0];
    }

    public static float ReadFloat(IntPtr h, long address)
    {
        return BitConverter.ToSingle(ReadBytes(h, address, 4), 0);
    }

    public static string ReadAscii(IntPtr h, long address, int max)
    {
        byte[] b = ReadBytes(h, address, max);
        int n = Array.IndexOf<byte>(b, 0);
        if (n < 0) n = b.Length;
        return Encoding.ASCII.GetString(b, 0, n);
    }

    public static void WriteFloat(IntPtr h, long address, float value)
    {
        byte[] bytes = BitConverter.GetBytes(value);
        UIntPtr wrote;

        bool ok = WriteProcessMemory(
            h,
            new IntPtr(address),
            bytes,
            new UIntPtr(4),
            out wrote);

        if (!ok || wrote.ToUInt64() != 4)
            throw new Win32Exception(
                Marshal.GetLastWin32Error(),
                "WriteProcessMemory failed at 0x" + address.ToString("X"));
    }

    public static void Close(IntPtr h)
    {
        if (h != IntPtr.Zero)
            CloseHandle(h);
    }
}
"@

# -------------------------
# Runtime state
# -------------------------
$script:GameProcess = $null
$script:GameHandle = [IntPtr]::Zero
$script:ModuleBase = [Int64]0
$script:ConnectedPid = 0
$script:LastDiscovery = [DateTime]::MinValue
$script:UserStopped = $false

$script:LastInGame = $null
$script:TransitionHoldUntil = [DateTime]::MinValue

$script:FovOriginal = $null
$script:FovLastWritten = $null
$script:FovPtr = [Int64]0
$script:FovWrote = $false

# Stored as "group:index" -> [volume, goalvolume, goalrate].
$script:MusicSaved = @{}

# -------------------------
# UI
# -------------------------
$form = New-Object System.Windows.Forms.Form
$form.Text = "MW2 Utility - V2.1 adaptive (experimental)"
$form.StartPosition = "CenterScreen"
$form.ClientSize = New-Object System.Drawing.Size(520, 350)
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false

$title = New-Object System.Windows.Forms.Label
$title.Text = "Modern Warfare 2 (2009) Utility"
$title.Font = New-Object System.Drawing.Font(
    "Segoe UI", 13, [System.Drawing.FontStyle]::Bold)
$title.AutoSize = $true
$title.Location = New-Object System.Drawing.Point(18,16)
$form.Controls.Add($title)

$subtitle = New-Object System.Windows.Forms.Label
$subtitle.Text = "Adaptive address discovery | FoV + music mute (experimental)"
$subtitle.AutoSize = $true
$subtitle.Location = New-Object System.Drawing.Point(20,46)
$form.Controls.Add($subtitle)

$groupFov = New-Object System.Windows.Forms.GroupBox
$groupFov.Text = "Field of View"
$groupFov.Location = New-Object System.Drawing.Point(18,78)
$groupFov.Size = New-Object System.Drawing.Size(230,105)
$form.Controls.Add($groupFov)

$chkFov = New-Object System.Windows.Forms.CheckBox
$chkFov.Text = "Maintain FoV"
$chkFov.Checked = $true
$chkFov.AutoSize = $true
$chkFov.Location = New-Object System.Drawing.Point(15,25)
$groupFov.Controls.Add($chkFov)

$numFov = New-Object System.Windows.Forms.NumericUpDown
$numFov.Minimum = 65
$numFov.Maximum = 90
$numFov.Value = 90
$numFov.Location = New-Object System.Drawing.Point(15,57)
$numFov.Size = New-Object System.Drawing.Size(70,25)
$groupFov.Controls.Add($numFov)

$lblRange = New-Object System.Windows.Forms.Label
$lblRange.Text = "65 - 90"
$lblRange.AutoSize = $true
$lblRange.Location = New-Object System.Drawing.Point(95,60)
$groupFov.Controls.Add($lblRange)

$groupAudio = New-Object System.Windows.Forms.GroupBox
$groupAudio.Text = "Audio"
$groupAudio.Location = New-Object System.Drawing.Point(268,78)
$groupAudio.Size = New-Object System.Drawing.Size(234,105)
$form.Controls.Add($groupAudio)

$chkMusic = New-Object System.Windows.Forms.CheckBox
$chkMusic.Text = "Disable all music"
$chkMusic.Checked = $true
$chkMusic.AutoSize = $true
$chkMusic.Location = New-Object System.Drawing.Point(15,25)
$groupAudio.Controls.Add($chkMusic)

$lblMusic = New-Object System.Windows.Forms.Label
$lblMusic.Text = "All 4 priority groups:`r`n13 menu, 32 music, 33 musicnopause"
$lblMusic.AutoSize = $true
$lblMusic.Location = New-Object System.Drawing.Point(15,51)
$groupAudio.Controls.Add($lblMusic)

$guard = New-Object System.Windows.Forms.Label
$guard.Text = "Writes pause after detected transitions; live testing still required."
$guard.AutoSize = $true
$guard.Location = New-Object System.Drawing.Point(20,196)
$form.Controls.Add($guard)

$activeGroupLabel = New-Object System.Windows.Forms.Label
$activeGroupLabel.Text = "Active sound priority group: -"
$activeGroupLabel.AutoSize = $true
$activeGroupLabel.Location = New-Object System.Drawing.Point(20,219)
$form.Controls.Add($activeGroupLabel)

$btnApply = New-Object System.Windows.Forms.Button
$btnApply.Text = "Connect / Apply"
$btnApply.Location = New-Object System.Drawing.Point(18,248)
$btnApply.Size = New-Object System.Drawing.Size(140,32)
$form.Controls.Add($btnApply)

$btnRestore = New-Object System.Windows.Forms.Button
$btnRestore.Text = "Restore && Stop"
$btnRestore.Location = New-Object System.Drawing.Point(168,248)
$btnRestore.Size = New-Object System.Drawing.Size(140,32)
$form.Controls.Add($btnRestore)

$btnReconnect = New-Object System.Windows.Forms.Button
$btnReconnect.Text = "Resume Auto-Connect"
$btnReconnect.Location = New-Object System.Drawing.Point(318,248)
$btnReconnect.Size = New-Object System.Drawing.Size(184,32)
$btnReconnect.Enabled = $false
$form.Controls.Add($btnReconnect)

$status = New-Object System.Windows.Forms.Label
$status.Text = "Starting..."
$status.BorderStyle = "Fixed3D"
$status.Location = New-Object System.Drawing.Point(18,297)
$status.Size = New-Object System.Drawing.Size(484,38)
$status.TextAlign = "MiddleLeft"
$form.Controls.Add($status)

function Set-Status([string]$text)
{
    if ($status.Text -ne $text)
    {
        $status.Text = $text
        $script:RecentStatus = @($script:RecentStatus + ((Get-Date -Format "HH:mm:ss") + " " + $text) | Select-Object -Last 128)
        try { $script:RecentStatus | Set-Content -LiteralPath $script:LogPath -Encoding UTF8 } catch {}
    }
}

function Game-IsAlive
{
    if (($null -eq $script:GameProcess) -or
        ($script:GameHandle -eq [IntPtr]::Zero))
    {
        return $false
    }

    try
    {
        $script:GameProcess.Refresh()
        return (-not $script:GameProcess.HasExited)
    }
    catch
    {
        return $false
    }
}

function Clear-ConnectionState
{
    if ($script:GameHandle -ne [IntPtr]::Zero)
    {
        try
        {
            [MW2SafeUtilityMemoryV2]::Close($script:GameHandle)
        }
        catch {}
    }

    $script:GameHandle = [IntPtr]::Zero
    $script:GameProcess = $null
    $script:ModuleBase = [Int64]0
    $script:ConnectedPid = 0
    $script:LastInGame = $null
    $script:TransitionHoldUntil = [DateTime]::MinValue

    $script:FovOriginal = $null
    $script:FovLastWritten = $null
    $script:FovPtr = [Int64]0
    $script:FovWrote = $false
    $script:MusicSaved = @{}

    $activeGroupLabel.Text = "Active sound priority group: -"
}

function Read-DvarNameAndBool(
    [Int64]$ptrRva,
    [string]$expectedName)
{
    $ptr = [MW2SafeUtilityMemoryV2]::ReadInt64(
        $script:GameHandle,
        $script:ModuleBase + $ptrRva)

    if ($ptr -eq 0)
    {
        throw "$expectedName is not initialized."
    }

    $namePtr = [MW2SafeUtilityMemoryV2]::ReadInt64(
        $script:GameHandle,
        $ptr)

    if ($namePtr -eq 0)
    {
        throw "$expectedName name pointer is null."
    }

    $name = [MW2SafeUtilityMemoryV2]::ReadAscii(
        $script:GameHandle,
        $namePtr,
        32)

    if ($name -ne $expectedName)
    {
        throw "Expected '$expectedName', found '$name'."
    }

    $value = [MW2SafeUtilityMemoryV2]::ReadByte(
        $script:GameHandle,
        $ptr + 0x10)

    return ($value -ne 0)
}

function Read-InGame
{
    return (Read-DvarNameAndBool $ClIngamePtrRva "cl_ingame")
}

function Validate-MusicChannels
{
    $count = [MW2SafeUtilityMemoryV2]::ReadInt32(
        $script:GameHandle,
        $script:ModuleBase + $ChannelCountRva)

    if (($count -le 33) -or ($count -gt 64))
    {
        throw "Sound channel table is not initialized."
    }

    foreach ($target in $AllMusicTargets)
    {
        $idx = [int]$target.Index

        $record =
            $script:ModuleBase +
            $ChannelTableRva +
            ([Int64]$idx * $ChannelRecordSize)

        $name = [MW2SafeUtilityMemoryV2]::ReadAscii(
            $script:GameHandle,
            $record,
            64)

        if ($name -ne [string]$target.Name)
        {
            throw "Sound channel validation failed at $idx."
        }
    }
}

function Validate-Fov
{
    $ptr = [MW2SafeUtilityMemoryV2]::ReadInt64(
        $script:GameHandle,
        $script:ModuleBase + $FovPointerRva)

    if ($ptr -eq 0)
    {
        throw "cg_fov is not initialized."
    }

    $namePtr = [MW2SafeUtilityMemoryV2]::ReadInt64(
        $script:GameHandle,
        $ptr)

    if ($namePtr -eq 0)
    {
        throw "cg_fov name pointer is null."
    }

    $name = [MW2SafeUtilityMemoryV2]::ReadAscii(
        $script:GameHandle,
        $namePtr,
        16)

    if ($name -ne "cg_fov")
    {
        throw "FoV validation failed."
    }

    $value = [MW2SafeUtilityMemoryV2]::ReadFloat(
        $script:GameHandle,
        $ptr + $FovCurrentOffset)

    if ([Single]::IsNaN($value) -or
        [Single]::IsInfinity($value) -or
        ($value -lt 40.0) -or
        ($value -gt 140.0))
    {
        throw "Unexpected cg_fov value."
    }

    return @($ptr,$value)
}

function Try-Connect
{
    if ($script:UserStopped)
    {
        return $false
    }

    $procs = @(Get-Process -Name "iw4mp" -ErrorAction SilentlyContinue)

    if ($procs.Count -eq 0)
    {
        Set-Status "Waiting for MW2 Multiplayer..."
        return $false
    }

    if ($procs.Count -ne 1)
    {
        Set-Status "Multiple iw4mp.exe processes found."
        return $false
    }

    $p = $procs[0]

    try
    {
        $exe = $p.MainModule.FileName
        $baseAddr = [Int64]$p.MainModule.BaseAddress.ToInt64()
        $hash = (Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash.ToUpperInvariant()

        $resolved = [MW2AddressResolver]::Resolve($exe)
        $script:FovPointerRva = $resolved[0]
        $script:ClIngamePtrRva = $resolved[1]
        $script:ChannelCountRva = $resolved[2]
        $script:ChannelTableRva = $resolved[3]
        $script:StateBaseRva = $resolved[4]
        $script:ActiveStatePtrRva = $resolved[5]
        $buildType = "new build; signatures validated"
        if ($hash -eq $ExpectedHash) { $buildType = "statically verified build" }
        Set-Status ("Resolved $buildType. SHA256: $hash; RVAs: " + (($resolved | ForEach-Object { "0x{0:X}" -f $_ }) -join ", "))

        $h = [MW2SafeUtilityMemoryV2]::Open($p.Id)

        $script:GameProcess = $p
        $script:GameHandle = $h
        $script:ModuleBase = $baseAddr
        $script:ConnectedPid = $p.Id

        # Runtime validation only. No write yet.
        [void](Read-InGame)
        Validate-MusicChannels

        $script:LastInGame = Read-InGame

        # Allows attaching even when opened mid-game without writing
        # immediately during an unknown transient frame.
        $script:TransitionHoldUntil = (Get-Date).AddMilliseconds(1500)

        Set-Status "MW2 connected. Safety warm-up: no writes for 1.5 seconds..."
        return $true
    }
    catch
    {
        Clear-ConnectionState
        Set-Status ("Connection pending: " + $_.Exception.Message)
        $script:UserStopped = $true
        $btnReconnect.Enabled = $true
        return $false
    }
}

function Get-ActiveMixerGroup
{
    $stateBase = $script:ModuleBase + $StateBaseRva

    $activePtr = [MW2SafeUtilityMemoryV2]::ReadInt64(
        $script:GameHandle,
        $script:ModuleBase + $ActiveStatePtrRva)

    for ($group = 0; $group -lt $BlockCount; $group++)
    {
        if ($activePtr -eq
            ($stateBase + ([Int64]$group * $StateBlockSize)))
        {
            return $group
        }
    }

    return -1
}

function Save-MixerEntryIfNeeded(
    [int]$group,
    [int]$idx,
    [Int64]$entry)
{
    $key = "$group`:$idx"

    if (-not $script:MusicSaved.ContainsKey($key))
    {
        $script:MusicSaved[$key] = @(
            [MW2SafeUtilityMemoryV2]::ReadFloat(
                $script:GameHandle,$entry + 0),
            [MW2SafeUtilityMemoryV2]::ReadFloat(
                $script:GameHandle,$entry + 4),
            [MW2SafeUtilityMemoryV2]::ReadFloat(
                $script:GameHandle,$entry + 8)
        )
    }
}

function Validate-MixerValues
{
    Validate-MusicChannels
    if ((Get-ActiveMixerGroup) -lt 0) { throw "Active mixer group is not initialized." }
    for ($group = 0; $group -lt $BlockCount; $group++) {
        foreach ($target in $AllMusicTargets) {
            $entry = $script:ModuleBase + $StateBaseRva + ([Int64]$group * $StateBlockSize) + ([Int64]$target.Index * $StateEntrySize)
            foreach ($offset in @(0,4,8)) {
                $v = [MW2SafeUtilityMemoryV2]::ReadFloat($script:GameHandle, $entry + $offset)
                if ([Single]::IsNaN($v) -or [Single]::IsInfinity($v) -or
                    (($offset -ne 8) -and (($v -lt 0) -or ($v -gt 1))) -or
                    (($offset -eq 8) -and ([Math]::Abs($v) -gt 1))) {
                    throw "Unexpected mixer value at group $group channel $($target.Index) offset $offset."
                }
            }
        }
    }
}

function Apply-MusicTargets-AllGroups($targets)
{
    if (-not $chkMusic.Checked)
    {
        return
    }

    Validate-MixerValues
    $stateBase = $script:ModuleBase + $StateBaseRva

    # All four channel-volume groups are maintained while the game state
    # is stable. This is the fix for music returning when ADS/scope,
    # hold-breath, pain or shellshock changes the active priority group.
    for ($group = 0; $group -lt $BlockCount; $group++)
    {
        $groupBase =
            $stateBase +
            ([Int64]$group * $StateBlockSize)

        foreach ($target in $targets)
        {
            $idx = [int]$target.Index
            $entry =
                $groupBase +
                ([Int64]$idx * $StateEntrySize)

            $volume = [MW2SafeUtilityMemoryV2]::ReadFloat(
                $script:GameHandle,$entry + 0)

            $goal = [MW2SafeUtilityMemoryV2]::ReadFloat(
                $script:GameHandle,$entry + 4)

            $rate = [MW2SafeUtilityMemoryV2]::ReadFloat(
                $script:GameHandle,$entry + 8)

            Save-MixerEntryIfNeeded $group $idx $entry

            # Only write when needed instead of blindly writing every tick.
            if ([Math]::Abs($volume) -gt 0.0001)
            {
                [MW2SafeUtilityMemoryV2]::WriteFloat(
                    $script:GameHandle,
                    $entry + 0,
                    [single]0.0)
            }

            if ([Math]::Abs($goal) -gt 0.0001)
            {
                [MW2SafeUtilityMemoryV2]::WriteFloat(
                    $script:GameHandle,
                    $entry + 4,
                    [single]0.0)
            }

            if ([Math]::Abs($rate) -gt 0.0001)
            {
                [MW2SafeUtilityMemoryV2]::WriteFloat(
                    $script:GameHandle,
                    $entry + 8,
                    [single]0.0)
            }
        }
    }
}

function Restore-Music
{
    if (-not (Game-IsAlive))
    {
        $script:MusicSaved = @{}
        return
    }

    try
    {
        $stateBase = $script:ModuleBase + $StateBaseRva

        Validate-MixerValues
        foreach ($key in @($script:MusicSaved.Keys))
        {
            $parts = $key.Split(":")
            $group = [int]$parts[0]
            $idx = [int]$parts[1]
            $values = $script:MusicSaved[$key]

            $entry =
                $stateBase +
                ([Int64]$group * $StateBlockSize) +
                ([Int64]$idx * $StateEntrySize)

            [MW2SafeUtilityMemoryV2]::WriteFloat(
                $script:GameHandle,
                $entry + 0,
                [single]$values[0])

            [MW2SafeUtilityMemoryV2]::WriteFloat(
                $script:GameHandle,
                $entry + 4,
                [single]$values[1])

            [MW2SafeUtilityMemoryV2]::WriteFloat(
                $script:GameHandle,
                $entry + 8,
                [single]$values[2])
        }
    }
    catch {}

    $script:MusicSaved = @{}
}

function Apply-Fov
{
    if (-not $chkFov.Checked)
    {
        return
    }

    $result = Validate-Fov
    $ptr = [Int64]$result[0]
    $current = [single]$result[1]
    $desired = [single]$numFov.Value

    if (($null -eq $script:FovOriginal) -or
        ($script:FovPtr -ne $ptr))
    {
        $script:FovOriginal = $current
        $script:FovPtr = $ptr
        $script:FovWrote = $false
    }

    if ([Math]::Abs($current - $desired) -gt 0.001)
    {
        [MW2SafeUtilityMemoryV2]::WriteFloat(
            $script:GameHandle,
            $ptr + $FovCurrentOffset,
            $desired)

        $script:FovLastWritten = $desired
        $script:FovWrote = $true
    }
}

function Restore-Fov
{
    if (($null -eq $script:FovOriginal) -or
        ($script:FovPtr -eq 0) -or
        (-not $script:FovWrote) -or
        (-not (Game-IsAlive)))
    {
        $script:FovOriginal = $null
        $script:FovLastWritten = $null
        $script:FovPtr = [Int64]0
        $script:FovWrote = $false
        return
    }

    try
    {
        $result = Validate-Fov
        $currentPtr = [Int64]$result[0]
        $current = [single]$result[1]

        if (($currentPtr -eq $script:FovPtr) -and
            ($null -ne $script:FovLastWritten) -and
            ([Math]::Abs(
                $current -
                [single]$script:FovLastWritten) -lt 0.001))
        {
            [MW2SafeUtilityMemoryV2]::WriteFloat(
                $script:GameHandle,
                $script:FovPtr + $FovCurrentOffset,
                [single]$script:FovOriginal)
        }
    }
    catch {}

    $script:FovOriginal = $null
    $script:FovLastWritten = $null
    $script:FovPtr = [Int64]0
    $script:FovWrote = $false
}

function Restore-All
{
    if (Game-IsAlive)
    {
        try
        {
            # Never deliberately restore into a match transition.
            if ((Get-Date) -ge $script:TransitionHoldUntil)
            {
                Restore-Music

                if (Read-InGame)
                {
                    Restore-Fov
                }
            }
        }
        catch {}
    }

    Clear-ConnectionState
}

function Update-Status([bool]$inGame)
{
    $activeGroup = Get-ActiveMixerGroup

    if ($activeGroup -ge 0)
    {
        $activeGroupLabel.Text =
            "Active sound priority group: $activeGroup"
    }
    else
    {
        $activeGroupLabel.Text =
            "Active sound priority group: changing"
    }

    if ($inGame)
    {
        $stateText = "IN GAME"
    }
    else
    {
        $stateText = "MENU"
    }

    if ($chkFov.Checked)
    {
        if ($inGame)
        {
            $fovText = "FoV $([int]$numFov.Value)"
        }
        else
        {
            $fovText = "FoV standby"
        }
    }
    else
    {
        $fovText = "FoV off"
    }

    if ($chkMusic.Checked)
    {
        $musicText = "Music mute requested (all groups)"
    }
    else
    {
        $musicText = "Music on"
    }

    Set-Status "$stateText | $fovText | $musicText"
}

# -------------------------
# UI events
# -------------------------
$btnApply.Add_Click({
    $script:UserStopped = $false
    $btnReconnect.Enabled = $false

    if (-not (Game-IsAlive))
    {
        Clear-ConnectionState
        [void](Try-Connect)
    }
})

$btnRestore.Add_Click({
    Restore-All
    $script:UserStopped = $true
    $btnReconnect.Enabled = $true
    Set-Status "Stopped. No automatic writes."
})

$btnReconnect.Add_Click({
    $script:UserStopped = $false
    $btnReconnect.Enabled = $false
    Set-Status "Auto-connect resumed..."
})

# Parser-safe form: function calls are explicitly parenthesized.
$chkMusic.Add_CheckedChanged({
    if ((-not $chkMusic.Checked) -and (Game-IsAlive))
    {
        try
        {
            if ((Get-Date) -ge $script:TransitionHoldUntil)
            {
                Restore-Music
            }
        }
        catch {}
    }
})

$chkFov.Add_CheckedChanged({
    if ((-not $chkFov.Checked) -and (Game-IsAlive))
    {
        try
        {
            if (((Get-Date) -ge $script:TransitionHoldUntil) -and
                (Read-InGame))
            {
                Restore-Fov
            }
        }
        catch {}
    }
})

$numFov.Add_ValueChanged({
    # No immediate memory write from this event. The normal timer applies
    # it only when cl_ingame is stable.
})

# -------------------------
# Main loop
# -------------------------
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 100

$timer.Add_Tick({
    try
    {
        if (-not (Game-IsAlive))
        {
            if ($script:ConnectedPid -ne 0)
            {
                Clear-ConnectionState
                Set-Status "MW2 closed. Waiting to reconnect automatically..."
            }

            if ($script:UserStopped)
            {
                return
            }

            $now = Get-Date

            if (($now - $script:LastDiscovery).TotalMilliseconds -ge 900)
            {
                $script:LastDiscovery = $now
                [void](Try-Connect)
            }

            return
        }

        $inGame = Read-InGame

        if ($null -eq $script:LastInGame)
        {
            $script:LastInGame = $inGame
            $script:TransitionHoldUntil =
                (Get-Date).AddMilliseconds(1500)
        }
        elseif ($inGame -ne $script:LastInGame)
        {
            $script:LastInGame = $inGame

            if ($inGame)
            {
                $script:TransitionHoldUntil =
                    (Get-Date).AddMilliseconds(2000)

                Set-Status (
                    "Match loading detected - ALL writes paused for 2 seconds...")
            }
            else
            {
                $script:TransitionHoldUntil =
                    (Get-Date).AddMilliseconds(3500)

                Set-Status (
                    "Match ending detected - ALL writes paused for 3.5 seconds...")
            }

            # Do not restore stale addresses/values during cgame/sound teardown.
            $script:FovOriginal = $null
            $script:FovLastWritten = $null
            $script:FovPtr = [Int64]0
            $script:FovWrote = $false
            $script:MusicSaved = @{}

            $activeGroupLabel.Text =
                "Active sound priority group: transition"

            return
        }

        if ((Get-Date) -lt $script:TransitionHoldUntil)
        {
            $remaining = [Math]::Max(
                0,
                ($script:TransitionHoldUntil - (Get-Date)).TotalSeconds)

            Set-Status (
                "Transition guard active - no writes ({0:N1}s)" -f
                $remaining)

            return
        }

        if ($chkMusic.Checked)
        {
            if ($inGame)
            {
                # All three proven channels, ALL FOUR mixer groups.
                Apply-MusicTargets-AllGroups $AllMusicTargets
            }
            else
            {
                # Menu music only, still across all four groups.
                Apply-MusicTargets-AllGroups $MenuOnlyTargets
            }
        }

        if ($chkFov.Checked -and $inGame)
        {
            Apply-Fov
        }

        Update-Status $inGame
    }
    catch
    {
        # Fail closed: stop touching this process until a clean reconnect.
        Clear-ConnectionState

        if (-not $script:UserStopped)
        {
            Set-Status (
                "Safety disconnect: " +
                $_.Exception.Message)
        }
    }
})

$form.Add_FormClosing({
    $timer.Stop()

    try
    {
        Restore-All
    }
    catch {}
})

$timer.Start()
Set-Status "Waiting for MW2 Multiplayer... Auto-connect is enabled."

[void]$form.ShowDialog()
