MW2 Utility V2.1 adaptive - experimental

Close previous utilities. Extract this ZIP into a new folder.
Start MW2 through Steam. Run "Launch MW2 Utility Transition Safe V2 - Console.bat".
The window title must show V2.1 adaptive. Auto-connect is enabled, as in V2.
If initialization is pending, wait until the menu finishes loading, then click Connect / Apply.
Compare FoV 65 and 90 while standing still and not aiming. Check music separately
in the menu, in a match, while aiming and after a match transition.
If it fails, send mw2-utility-log.txt. Only the latest 128 status messages are retained;
the previous session's log is replaced when this session first logs a message.
Restore & Stop attempts to restore captured values; restarting the game clears
remaining process-memory changes if restoration cannot complete.

AUTOMATIC ADDRESS DISCOVERY
This version scans the on-disk executable's .text section using five code signatures.
It cross-checks cg_fov registration against the camera read, cl_ingame's name,
and the sound channel count and mixer entry/record layout. Resolved destinations
must lie in writable data sections. Live setting and channel names and mixer values
are checked before music writes. It does not patch the executable or game archives.
There is no fixed-address fallback and no hash-only bypass. SHA256 identifies the
build in diagnostics; it is no longer the sole compatibility gate. Missing or
ambiguous signatures stop connection. A later compiler/code-layout change can still
require a manual update. This is guarded address discovery, not universal self-repair.

VERIFICATION AND LIMITS
The uploaded FD3AFF1F539525F5A798C5F5953DDBF651037AFBC52D50C5ABBEA749EFD2ABE2
executable passes static signature and cross-reference checks. Verification also
checks missing and duplicate signature cases. verify_resolver.py reproduces these
read-only checks with Python. The PowerShell/C# source has NOT been compiled or
run on Windows here. Live FOV changes, audible music muting, restoration and
transitions remain untested on this build. Runtime checks cannot make external
memory writes atomic with game updates. The inherited transition timing is a
best-effort delay, not a guarantee. Anti-cheat compatibility is unverified.

Source is included in the .ps1. Old V2 launch filenames are retained for consistency.
Resolved RVAs on the uploaded executable:
FOV pointer 0x6BD178; cl_ingame 0xD050E0; channel count 0x651C800;
channel table 0x651B2F8; mixer blocks 0x651A564; active mixer pointer 0x651B178.
