"""Read-only checks for adaptive resolver signatures. Usage: python verify_resolver.py iw4mp.exe"""
import re,struct,sys
from pathlib import Path
b=Path(sys.argv[1]).read_bytes();p=struct.unpack_from('<I',b,60)[0];n=struct.unpack_from('<H',b,p+6)[0];st=p+24+struct.unpack_from('<H',b,p+20)[0]
sects=[struct.unpack_from('<8sIIII',b,st+i*40) for i in range(n)]
_,vs,tr,ts,to=next(s for s in sects if s[0].rstrip(b'\0')==b'.text')
source=next(Path(__file__).parent.glob('*.ps1')).read_text(encoding='utf-8-sig')
patterns=re.findall(r'int (\w+)=Find\("([^"]+)"\)',source)
def hits(buf,pat):
 r=b''.join(b'.' if x=='??' else re.escape(bytes([int(x,16)])) for x in pat.split())
 return [m.start() for m in re.finditer(r,buf,re.S)]
found={}
for name,pat in patterns:
 h=hits(b[to:to+ts],pat);assert len(h)==1,(name,h)
 found[name]=h[0]+to
 # The same resolver must reject missing/ambiguous signatures.
 frag=b[to+h[0]:to+h[0]+len(pat.split())]
 assert len(hits(frag+frag,pat))==2
 damaged=bytes([frag[0]^255])+frag[1:];assert not hits(damaged,pat)
def rip(o,l,d): return o-to+tr+l+struct.unpack_from('<i',b,o+d)[0]
f,g,m,t,c=[found[x] for x in ['f','g','m','t','camera']]
def raw(r):
 for _,vs,rva,size,off in sects:
  if rva<=r<rva+size:return off+r-rva
 raise ValueError(r)
assert b[raw(rip(f,7,3)):][:7]==b'cg_fov\0'
assert b[raw(rip(g,7,3)):][:10]==b'cl_ingame\0'
assert b[f+91:f+94]==bytes.fromhex('48 89 05')
assert rip(c,7,3)==rip(f+91,7,3)
assert b[m+113:m+116]==bytes.fromhex('44 39 05')
assert b[m+185:m+189]==bytes.fromhex('48 83 c1 0c')
assert rip(t,6,2)==rip(m+113,7,3)
resolved=[rip(f+91,7,3),rip(g+18,7,3),rip(m+113,7,3),rip(t+8,7,3),rip(m,7,3),rip(m+25,7,3)]
assert resolved==[0x6bd178,0xd050e0,0x651c800,0x651b2f8,0x651a564,0x651b178]
print('PASS: five unique signatures, setting strings, camera cross-check, mixer stride/count cross-check.')
print('PASS: missing/duplicate signature rejection cases; resolved RVAs:', ', '.join(hex(x) for x in resolved))
print('Windows PowerShell compilation and live-game behavior require Windows testing.')
